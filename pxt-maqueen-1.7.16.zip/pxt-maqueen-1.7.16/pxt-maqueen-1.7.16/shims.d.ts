// Auto-generated. Do not edit.



    //% color=50 weight=80
    //% icon="\uf1eb"
declare namespace maqueenIRV2 {
}

// Auto-generated. Do not edit. Really.
