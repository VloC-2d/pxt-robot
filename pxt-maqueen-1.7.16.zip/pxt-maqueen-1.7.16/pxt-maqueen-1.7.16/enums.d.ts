// Auto-generated. Do not edit.
declare namespace maqueenIRV2 {
}

// Auto-generated. Do not edit. Really.
